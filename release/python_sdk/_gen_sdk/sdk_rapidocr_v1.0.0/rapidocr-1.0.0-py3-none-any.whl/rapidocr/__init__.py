# !/usr/bin/env python
# -*- encoding: utf-8 -*-
# @File: __init__.py
# @Author: Max
from .rapidocr import TextSystem
