#### test_images_benchmark
- 基准的测试图像，便于测试情况下统一基准，主要用于评测推理性能，侧重于速度方面。
- 一共251张图像，类型涉及自然场景、文档类、广告海报、卡证类和手写体等样式，涉及语种为中英文。

#### 下载链接
- [百度网盘](https://pan.baidu.com/s/1R4gYtJt2G3ypGkLWGwUCKg?pwd=ceuo)
- [Google Drive](https://drive.google.com/drive/folders/1IIOCcUXdWa43Tfpsiy6UQJmPsZLnmgFh?usp=sharing)

#### 贡献者
<p align="left">
    <a href="https://github.com/zhsunlight"><img src="https://avatars.githubusercontent.com/u/56898908?v=4" width=65 height=65></a>
</p>