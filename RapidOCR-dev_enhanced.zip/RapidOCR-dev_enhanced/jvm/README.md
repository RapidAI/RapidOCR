# JVM项目

### JVM项目使用onnxruntime和ncnn两种推理框架，实现了2种版本
### onnxruntime版：[RapidOcrOnnxJvm](https://github.com/RapidAI/RapidOcrOnnxJvm)
### ncnn版：[RapidOcrNcnnJvm](https://github.com/RapidAI/RapidOcrNcnnJvm)
### 以下内容停止更新

## 简介
本目录存放Jvm相关demo项目
1. RapidOcrOnnxJvm项目: 通过jni调用RapidOcrOnnx项目编译的动态运行库范例，内含java和kotlin调用范例，附调试和编译相关说明