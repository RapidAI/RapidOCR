You need to put your library files here in its appropriate directory respectively.

Mainly you need put your onnxruntime library file in its correct directory.
