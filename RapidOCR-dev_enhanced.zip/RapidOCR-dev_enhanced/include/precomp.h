#pragma once
#include "OcrUtils.h"
#include "rapidocr_api.h"
#include "omp.h"
#include "OcrLite.h"
#include "opencv2/imgcodecs.hpp"