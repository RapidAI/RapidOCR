---
name: Feature Request
about: requests for new RapidOCR features
title: 'Feature Request'
labels: 'Feature Request'
assignees: ''

---

请您详细描述想要添加的新功能或者是新特性
(Please describe in detail the new function or new feature you want to add)
