---
name: Blank Template
about: Blank Template
title: 'Blank Template'
labels: 'Blank Template'
assignees: ''

---