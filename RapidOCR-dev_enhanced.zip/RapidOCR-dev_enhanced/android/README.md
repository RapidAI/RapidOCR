# Android版Ocr范例

#### 介绍
* ~~本目录存放Android相关demo项目~~
* ~~* BaiPiaoOcrAndroidOnnx项目是Android平台范例，采用onnxruntime为推理框架~~
* 为方便管理，此文件夹代码不再更新，Android demo移至[RapidOcrAndroidOnnx](https://github.com/RapidAI/RapidOcrAndroidOnnx) 
