# .Net版RapidOcr范例

#### 介绍
本目录存放.Net相关demo项目
* RapidOcrOnnxCs项目是Windows平台C# WinForm范例，采用onnxruntime为推理框架
