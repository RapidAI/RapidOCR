#ifndef __OCR_VERSION_H__
#define __OCR_VERSION_H__

#define VERSION "1.0.2"

#endif //__OCR_VERSION_H__
